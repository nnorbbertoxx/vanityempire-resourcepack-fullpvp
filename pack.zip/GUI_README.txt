VanityEmpire FullPvP V28 - GUI texture mapping

Benne van:
- BattlePass GUI
- EnderChest GUI
- Shopkeeper / Töredék Átváltó GUI

Automatikus vanilla mapping a packben:
- assets/minecraft/textures/gui/container/generic_54.png      -> BattlePass stílus
- assets/minecraft/textures/gui/container/shulker_box.png     -> EnderChest stílus
- assets/minecraft/textures/gui/container/merchant.png        -> Shopkeeper / Töredék Átváltó stílus

Külön custom fájlok is bent vannak későbbi kézi kötéshez:
- assets/vanityempire/textures/gui/battlepass.png
- assets/vanityempire/textures/gui/enderchest.png
- assets/vanityempire/textures/gui/shopkeeper.png
- assets/vanityempire/textures/gui/generic_54_enderchest_alt.png

Ha azt szeretnéd, hogy az EnderChest a generic_54-et használja BattlePass helyett,
akkor a generic_54_enderchest_alt.png fájlt nevezd át generic_54.png-ra,
és cseréld le vele a jelenlegi generic_54.png-t.
