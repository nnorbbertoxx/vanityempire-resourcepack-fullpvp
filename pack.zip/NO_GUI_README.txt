VanityEmpire Global V31

A custom GUI texture overrides teljesen eltávolítva.
A Minecraft alap GUI-k jelennek meg újra.
A láda-, logo-, ikon- és rangprefix textúrák megmaradtak.
