FullPvP V30 GUI tuning

Plugin célzás:
- BattlePass-v8.2
- ShopGUIPlus
- Shopkeepers

Mi változott:
- Kivettem a "VanityEmpire • FullPvP" brandinget.
- A Shopkeepers villager GUI-ból kivettem a ráégetett címeket, így nem fog összeakadni a plugin saját címsorával.
- A BattlePass egyedi háttérből kivettem az alsó brandinget.
- Az Enderláda egyedi háttérből kivettem az alsó brandinget.

Ajánlott BattlePass cím:
  gui:
    battlepass: ""

Megjegyzés:
- ShopGUIPlus automatikusan a generic_54 chest GUI-t fogja használni.
- Shopkeepers automatikusan a villager GUI-t fogja használni.
- Enderláda a custom ender chest GUI-t használhatja a beállított font karakter alapján.
