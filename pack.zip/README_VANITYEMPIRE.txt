VanityEmpire Global Resource Pack - V34

Minecraft Java: 1.21.x
Declared pack compatibility:
- 1.21 - 1.21.1: format 34
- 1.21.2 - 1.21.3: format 42
- 1.21.4: format 46
- 1.21.5: format 55
- 1.21.6: format 63
- 1.21.7 - 1.21.8: format 64
- 1.21.9 - 1.21.10: format 69
- 1.21.11: format 75

Final global rank visuals:
- TULAJ has a unique black/gold premium badge + crown.
- All other rank colors remain as approved.
- Each LuckPerms glyph contains icon + prefix together.
- No custom GUI overrides are included.

Not included:
Custom, Limited, SMP, Muted, Teszt, Bot.

After upload:
  /rp check send
