VanityEmpire V49 TRUE UNIVERSAL
Target: Minecraft Java 1.20 - 1.21.11

Why this exists:
- Old clients can reject bitmap font glyph textures larger than 256px in either dimension.
- The approved combined rank textures were 372x80.
- V49 does NOT resize/repaint the rank art.
- Each 372x80 source is split into its original icon pixels and original name/badge pixels.
- Every resulting font bitmap is <=256px.
- Font height/ascent stays 10/9.
- HUD, crates, models and other textures are unchanged.
