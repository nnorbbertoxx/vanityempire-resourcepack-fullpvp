VanityEmpire FullPvP V29 - Native GUI fix

A korábbi V28-ban a teljes 1448x1086 mockup képet tettem rá a vanilla GUI textúrára, ezért a kép szétcsúszott és minden chest GUI BattlePass lett. V29 ezt javítja.

Most:
- generic_54.png: natív 256x256 atlas, nem torzul.
- EnderChest: automatikus egyedi lila EnderLáda háttér a kliens nyelvi kulcsán keresztül.
- Shopkeeper / Töredék Átváltó: assets/minecraft/textures/gui/container/villager.png natív 512x256 atlas.
- BattlePass: külön title-glyph background, ezért CSAK a BattlePass menün jelenik meg.

BattlePass pluginban a GUI title legyen pontosan ez a két karakter:


Megjelenítve: 

Ha a plugin MiniMessage-et használ, sima szövegként tedd a title mezőbe, ne színezd.
A játékban a két karakter helyett a teljes BattlePass GUI background fog megjelenni.

EnderChesthez nem kell title-t állítani, ha a kliens hu_hu vagy en_us nyelvet használ.

Shopkeeper a vanilla merchant/villager képernyőt fogja skinelni, tehát minden ilyen merchant GUI ezt a stílust kapja.

Resource pack frissítés után:
/rp check send
