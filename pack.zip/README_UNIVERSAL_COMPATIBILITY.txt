VanityEmpire V48 UNIVERSAL
Target: Minecraft Java 1.20 through 1.21.11

Only pack.mcmeta compatibility metadata was changed from V47.
Rank PNGs, glyphs, height/ascent, HUD, crates, models and textures are unchanged.
For server use, upload this ZIP as pack.zip and refresh NBTXResourcePack.
